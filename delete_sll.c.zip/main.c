/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

struct node{
    int data;
    struct node *link;

};

struct node * del_end(struct node* head);

int main()
{
    
    struct node *head=malloc(sizeof(struct node));
    head->data=10;
    head->link=NULL;
    
    struct node *current=malloc(sizeof(struct node));
    current->data=20;
    current->link=NULL;
    head->link=current;
   
    current=malloc(sizeof(struct node));
    current->data=30;
    current->link=NULL;
    head->link->link=current;
    
   
    head=del_end(head);
    struct node *temp=head;
    if (head==NULL)
        printf("SLL deleted successfully");
    while(temp!=NULL)
    {
        printf("%d->",temp->data);
        temp=temp->link;
    }
    
}

struct node * del_end(struct node* head)
{
    struct node *temp=head;
    if(temp==NULL)
        printf("Single linked list is empty");
    else if(temp->link==NULL)
    {
        free(temp);
        head=NULL;
    }
    else
    {
        while(temp!=NULL)
        {
           temp=temp->link; 
           free(head);
           head=temp;
        }
       
        
    }
    return head;
}


