/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
struct node{
    int data;
    struct node *link;

};

void add_random(struct node* head);
void print_data(struct node *head);
int main()
{
    
    struct node *head=malloc(sizeof(struct node));
    head->data=10;
    head->link=NULL;
    
    struct node *current=malloc(sizeof(struct node));
    current->data=20;
    current->link=NULL;
    head->link=current;
    
    current=malloc(sizeof(struct node));
    current->data=30;
    current->link=NULL;
    head->link->link=current;
    
    add_random(head);
    print_data(head);
  
    return 0;
}
void add_random(struct node* head)
{
    struct node *new=malloc(sizeof(struct node));
    new->data=5;
    new->link=NULL;
    
    int pos=3;
    struct node *temp=head;
    pos--;
    while(pos!=1)
    {
        temp=temp->link;
        pos--;
    }
    new->link=temp->link;
    temp->link=new;
    
}
void print_data(struct node *head)
{
    struct node *temp=head;
    
    while(temp!=NULL)
    {
        printf("%d->",temp->data); 
        temp=temp->link;
    }
  
}


