#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node *link;
};

int main()
{
    
    struct node *head=(struct node*)malloc(sizeof(struct node));
    struct node *current=(struct node*)malloc(sizeof(struct node));
    
    head->data=10;
    head->link=NULL;
    
    current->data=40;
    current->link=NULL;
    head->link=current;
    
    current=malloc(sizeof(struct node));
    current->data=50;
    current->link=NULL;
    
    head->link->link=current;
    
    struct node *ptr=NULL;
    ptr=head;
    if (ptr==NULL)
        printf("none");
    while (ptr!=NULL)
    {
        printf("%3d",ptr->data);
        ptr=ptr->link;
    }
    return 0;
    
    
}
