/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

struct node{
    int data;
    struct node *link;

};

struct node * del_begin(struct node* head);
void print_data(struct node* head);

int main()
{
    
    struct node *head=malloc(sizeof(struct node));
    head->data=10;
    head->link=NULL;
    
    struct node *current=malloc(sizeof(struct node));
    current->data=20;
    current->link=NULL;
    head->link=current;
    
    current=malloc(sizeof(struct node));
    current->data=30;
    current->link=NULL;
    head->link->link=current;
    
   
    head=del_begin(head);
    struct node *temp=head;
    while(temp!=NULL)
    {
        printf("%d->",temp->data); 
        temp=temp->link;
    }
  
    return 0;
}

struct node * del_begin(struct node* head)
{
    if (head==NULL)
        printf("Empty list");
    else
    {
        struct node *temp=head;
        head=head->link;
        free(temp);
        temp=NULL;
    }
    
    return head;
}
