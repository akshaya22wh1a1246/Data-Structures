/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
struct node{
    int data;
    struct node *link;

};

void search(struct node* head,int key);
//void print_data(struct node *head);
int main()
{
    int key;
    struct node *head=malloc(sizeof(struct node));
    head->data=10;
    head->link=NULL;
    
    struct node *current=malloc(sizeof(struct node));
    current->data=20;
    current->link=NULL;
    head->link=current;
    
    current=malloc(sizeof(struct node));
    current->data=30;
    current->link=NULL;
    head->link->link=current;
    
    printf("Enter the key to search");
    scanf("%d",&key);
    search(head,key);
    //print_data(head);
  
    return 0;
}
void search(struct node* head,int key)
{
    struct node *temp=head;
    int c=0;
    while(temp!=NULL)
    {
        if (temp->data==key)
            c++;
        temp=temp->link;
        
    }
    if(c==0)
        printf("Search key is not found");
    else
        printf("Search key is found");
    
}
/*void print_data(struct node *head)
{
    struct node *temp=head;
    while(temp!=NULL)
    {
        printf("%d->",temp->data); 
        temp=temp->link;
    }
  
}*/




